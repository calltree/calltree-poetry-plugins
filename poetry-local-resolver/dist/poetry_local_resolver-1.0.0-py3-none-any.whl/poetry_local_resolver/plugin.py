"""Poetry plugin that adds --local flag to use workspace packages."""

import os
import logging
from pathlib import Path
from typing import Dict, Optional
from copy import deepcopy

from cleo.io.io import IO
from poetry.console.application import Application
from poetry.console.commands.install import InstallCommand
from poetry.plugins.application_plugin import ApplicationPlugin
from poetry.core.packages.directory_dependency import DirectoryDependency
from cleo.helpers import option

logger = logging.getLogger(__name__)


class LocalInstallCommand(InstallCommand):
    """Extended install command with --local flag."""
    
    name = "install"
    options = InstallCommand.options + [
        option("local", "L", "Use local workspace packages when available"),
    ]
    
    def handle(self) -> int:
        """Handle the install command with local workspace discovery."""
        use_local = self.option("local")
        
        if use_local:
            # Discover and apply local packages WITHOUT modifying pyproject.toml
            workspace_packages = self._discover_workspace_packages()
            if workspace_packages:
                self.line("")
                self.line("<comment>Using local workspace packages:</comment>")
                for name, path in workspace_packages.items():
                    rel_path = os.path.relpath(path, Path.cwd())
                    self.line(f"  • {name} → {rel_path}")
                self.line("")
                
                # Override the package dependencies in memory only
                self._override_dependencies_in_memory(workspace_packages)
        
        # Run the normal install
        return super().handle()
    
    def _discover_workspace_packages(self) -> Dict[str, Path]:
        """Discover packages in the workspace that match project dependencies."""
        workspace_packages = {}
        project_dir = Path.cwd()
        workspace_dir = project_dir.parent
        
        # Get project dependencies
        project_deps = set()
        if self.poetry and self.poetry.package:
            for dep in self.poetry.package.all_requires:
                project_deps.add(dep.name)
        
        # Patterns to exclude
        exclude_patterns = [
            "__pycache__", ".git", ".venv", "venv", 
            "node_modules", ".tox", "dist", "build", 
            ".Trash", ".cache", "Library"
        ]
        
        try:
            for item in workspace_dir.iterdir():
                if not item.is_dir():
                    continue
                    
                # Skip excluded directories
                if any(pattern in item.name for pattern in exclude_patterns):
                    continue
                
                # Skip the current project directory
                if item.resolve() == project_dir.resolve():
                    continue
                    
                # Check for pyproject.toml
                pyproject = item / "pyproject.toml"
                if pyproject.exists() and os.access(pyproject, os.R_OK):
                    package_name = self._get_package_name(pyproject)
                    # Only include if it's a dependency of this project
                    if package_name and package_name in project_deps:
                        workspace_packages[package_name] = item
                        
        except Exception as e:
            logger.debug(f"Error discovering workspace packages: {e}")
            
        return workspace_packages
    
    def _get_package_name(self, pyproject_path: Path) -> Optional[str]:
        """Extract package name from pyproject.toml."""
        try:
            import toml
            data = toml.load(pyproject_path)
            
            # Try Poetry section first
            poetry_section = data.get("tool", {}).get("poetry", {})
            if "name" in poetry_section:
                return poetry_section["name"]
            
            # Try PEP 621 project section
            project_section = data.get("project", {})
            if "name" in project_section:
                return project_section["name"]
        except Exception:
            pass
        return None
    
    def _override_dependencies_in_memory(self, workspace_packages: Dict[str, Path]):
        """Override package dependencies in memory to use local paths."""
        try:
            if not self.poetry or not self.poetry.package:
                return
            
            package = self.poetry.package
            
            # Create new dependency list with local overrides
            new_requires = []
            for dep in package.all_requires:
                if dep.name in workspace_packages:
                    # Replace with directory dependency
                    local_dep = DirectoryDependency(
                        name=dep.name,
                        path=workspace_packages[dep.name],
                        develop=True
                    )
                    new_requires.append(local_dep)
                    logger.info(f"Overriding {dep.name} to use local path")
                else:
                    new_requires.append(dep)
            
            # Replace the requires list (this is in-memory only)
            package._dependency_groups["main"] = new_requires
            
        except Exception as e:
            logger.error(f"Failed to override dependencies: {e}")


class LocalResolverPlugin(ApplicationPlugin):
    """Plugin that adds --local flag for workspace package discovery."""
    
    def activate(self, application: Application, io: Optional[IO] = None) -> None:
        """Activate the plugin and replace the install command."""
        
        try:
            # Replace the install command with our extended version
            factory = application.command_loader
            if factory and hasattr(factory, "_factories"):
                # Override the install command factory
                factory._factories["install"] = lambda: LocalInstallCommand()
                logger.info("Local resolver plugin activated - use 'poetry install --local'")
                
        except Exception as e:
            logger.debug(f"Failed to activate local resolver: {e}")