"""Poetry plugin that silently overrides dependencies to use local workspace packages."""

import os
import logging
from pathlib import Path
from typing import Dict, Optional

from cleo.io.io import IO
from poetry.console.application import Application
from poetry.plugins.application_plugin import ApplicationPlugin

logger = logging.getLogger(__name__)


class LocalResolverPlugin(ApplicationPlugin):
    """A Poetry plugin that silently overrides to use local workspace packages."""
    
    def activate(self, application: Application, io: Optional[IO] = None) -> None:
        """Activate the plugin and patch Poetry's dependency resolution."""
        
        try:
            if not hasattr(application, 'poetry') or not application.poetry:
                return
                
            project_dir = Path.cwd()
            
            # Scan workspace for local packages
            workspace_packages = self._scan_workspace(project_dir)
            
            if not workspace_packages:
                return
            
            # Hook into the installer to override package sources
            from poetry.installation.installer import Installer
            if hasattr(Installer, 'run'):
                original_run = Installer.run
                
                def run_with_overrides(self):
                    """Override installer run to use local packages."""
                    # Modify the pool to prioritize local packages
                    if hasattr(self, '_pool'):
                        pool = self._pool
                        for name, local_path in workspace_packages.items():
                            logger.info(f"Using local path for {name}: {local_path}")
                            # This is where we'd inject local package info
                            # But Poetry's internal structure makes this complex
                    
                    return original_run(self)
                
                Installer.run = run_with_overrides
            
            # For now, just log what we found
            if workspace_packages and io:
                io.write_line("")
                io.write_line("<comment>Poetry Local Resolver: Found local packages</comment>")
                for name, path in workspace_packages.items():
                    rel_path = os.path.relpath(path, project_dir)
                    io.write_line(f"  • {name} at {rel_path}")
                io.write_line("<comment>Note: Automatic override is in development</comment>")
                io.write_line("<comment>For now, use: poetry add {package} --editable {path}</comment>")
                io.write_line("")
                
        except Exception as e:
            logger.debug(f"Local resolver error: {e}")
    
    def _scan_workspace(self, project_dir: Path) -> Dict[str, Path]:
        """Scan the parent workspace directory for Python packages."""
        
        workspace_packages = {}
        workspace_dir = project_dir.parent
        
        # Patterns to exclude
        exclude_patterns = [
            "__pycache__", ".git", ".venv", "venv", 
            "node_modules", ".tox", "dist", "build", 
            ".Trash", ".cache", "Library"
        ]
        
        try:
            for item in workspace_dir.iterdir():
                if not item.is_dir():
                    continue
                    
                # Skip excluded directories
                if any(pattern in item.name for pattern in exclude_patterns):
                    continue
                
                # Skip the current project directory
                if item.resolve() == project_dir.resolve():
                    continue
                    
                # Check for pyproject.toml
                pyproject = item / "pyproject.toml"
                if pyproject.exists() and os.access(pyproject, os.R_OK):
                    package_name = self._get_package_name_from_pyproject(pyproject)
                    if package_name:
                        # Only include if it's a project dependency
                        if self._is_project_dependency(project_dir, package_name):
                            workspace_packages[package_name] = item
                        
        except Exception as e:
            logger.debug(f"Error scanning workspace: {e}")
            
        return workspace_packages
    
    def _get_package_name_from_pyproject(self, pyproject_path: Path) -> Optional[str]:
        """Extract package name from pyproject.toml."""
        try:
            import toml
            data = toml.load(pyproject_path)
            
            # Try Poetry section first
            poetry_section = data.get("tool", {}).get("poetry", {})
            if "name" in poetry_section:
                return poetry_section["name"]
            
            # Try PEP 621 project section
            project_section = data.get("project", {})
            if "name" in project_section:
                return project_section["name"]
        except Exception as e:
            logger.debug(f"Failed to parse {pyproject_path}: {e}")
        
        return None
    
    def _is_project_dependency(self, project_dir: Path, package_name: str) -> bool:
        """Check if a package is a dependency of the current project."""
        try:
            pyproject_path = project_dir / "pyproject.toml"
            if not pyproject_path.exists():
                return False
                
            import toml
            data = toml.load(pyproject_path)
            poetry_section = data.get("tool", {}).get("poetry", {})
            
            # Check main dependencies
            deps = poetry_section.get("dependencies", {})
            if package_name in deps:
                return True
            
            # Check all dependency groups
            groups = poetry_section.get("group", {})
            for group_name, group_data in groups.items():
                if package_name in group_data.get("dependencies", {}):
                    return True
                    
            # Check legacy dev-dependencies
            if package_name in poetry_section.get("dev-dependencies", {}):
                return True
                
        except Exception as e:
            logger.debug(f"Error checking dependencies: {e}")
            
        return False