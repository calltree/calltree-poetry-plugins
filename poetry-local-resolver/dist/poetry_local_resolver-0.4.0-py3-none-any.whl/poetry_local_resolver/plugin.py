"""Poetry plugin that automatically detects and suggests local workspace packages."""

import os
import logging
from pathlib import Path
from typing import Dict, Optional

from cleo.io.io import IO
from poetry.console.application import Application
from poetry.plugins.application_plugin import ApplicationPlugin

logger = logging.getLogger(__name__)


class LocalResolverPlugin(ApplicationPlugin):
    """A Poetry plugin that detects workspace packages and suggests using them locally."""
    
    def activate(self, application: Application, io: Optional[IO] = None) -> None:
        """Activate the plugin and scan for local packages."""
        
        try:
            project_dir = Path.cwd()
            
            # Check if we have a pyproject.toml
            pyproject_path = project_dir / "pyproject.toml"
            if not pyproject_path.exists():
                return
            
            # Scan workspace for local packages
            workspace_packages = self._scan_workspace(project_dir)
            
            if not workspace_packages:
                return
            
            # Load the current project's dependencies
            import toml
            pyproject_data = toml.load(pyproject_path)
            
            # Get all dependencies (main and dev)
            project_deps = set()
            poetry_section = pyproject_data.get("tool", {}).get("poetry", {})
            
            # Check main dependencies
            deps = poetry_section.get("dependencies", {})
            for dep_name in deps:
                if dep_name != "python":
                    project_deps.add(dep_name)
            
            # Check dev dependencies
            dev_deps = poetry_section.get("group", {}).get("dev", {}).get("dependencies", {})
            for dep_name in dev_deps:
                project_deps.add(dep_name)
            
            # Find which local packages could be used
            available_local = workspace_packages.keys() & project_deps
            
            if available_local and io:
                io.write_line("")
                io.write_line("<comment>Poetry Local Resolver Plugin</comment>")
                io.write_line("<comment>=" * 40 + "</comment>")
                io.write_line("<info>Found local workspace packages that could be used:</info>")
                
                for pkg_name in sorted(available_local):
                    local_path = workspace_packages[pkg_name]
                    relative_path = os.path.relpath(local_path, project_dir)
                    
                    # Check if already using local path
                    dep_spec = deps.get(pkg_name, dev_deps.get(pkg_name))
                    if isinstance(dep_spec, dict) and dep_spec.get("path"):
                        io.write_line(f"  ✓ {pkg_name} (already using local: {dep_spec['path']})")
                    else:
                        io.write_line(f"  • {pkg_name} at {relative_path}")
                        io.write_line(f"    <comment>To use locally, run: poetry add {pkg_name} --path {relative_path}</comment>")
                
                io.write_line("")
                
        except Exception as e:
            logger.debug(f"Error in local resolver plugin: {e}")
    
    def _scan_workspace(self, project_dir: Path) -> Dict[str, Path]:
        """Scan the parent workspace directory for Python packages."""
        
        workspace_packages = {}
        workspace_dir = project_dir.parent
        
        # Patterns to exclude
        exclude_patterns = [
            "__pycache__", ".git", ".venv", "venv", 
            "node_modules", ".tox", "dist", "build", 
            ".Trash", ".cache", "Library"
        ]
        
        try:
            for item in workspace_dir.iterdir():
                if not item.is_dir():
                    continue
                    
                # Skip excluded directories
                if any(pattern in item.name for pattern in exclude_patterns):
                    continue
                
                # Skip the current project directory
                if item.resolve() == project_dir.resolve():
                    continue
                    
                # Check for pyproject.toml
                pyproject = item / "pyproject.toml"
                if pyproject.exists() and os.access(pyproject, os.R_OK):
                    package_name = self._get_package_name_from_pyproject(pyproject)
                    if package_name:
                        workspace_packages[package_name] = item
                        
        except Exception as e:
            logger.debug(f"Error scanning workspace: {e}")
            
        return workspace_packages
    
    def _get_package_name_from_pyproject(self, pyproject_path: Path) -> Optional[str]:
        """Extract package name from pyproject.toml."""
        try:
            import toml
            data = toml.load(pyproject_path)
            
            # Try Poetry section first
            poetry_section = data.get("tool", {}).get("poetry", {})
            if "name" in poetry_section:
                return poetry_section["name"]
            
            # Try PEP 621 project section
            project_section = data.get("project", {})
            if "name" in project_section:
                return project_section["name"]
        except Exception as e:
            logger.debug(f"Failed to parse {pyproject_path}: {e}")
        
        return None